$.extend($.fn.treegrid.defaults, {
    expanderExpandedClass: 'oi oi-minus',
    expanderCollapsedClass: 'oi oi-plus'
});